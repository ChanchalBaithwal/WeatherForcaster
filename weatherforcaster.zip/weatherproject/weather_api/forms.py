from django import forms
class UserSignupForm(forms.Form):
    Email = forms.CharField(widget= forms.EmailInput)
    password = forms.CharField(widget= forms.PasswordInput)