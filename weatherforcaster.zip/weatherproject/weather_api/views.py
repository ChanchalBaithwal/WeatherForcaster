from django.shortcuts import render, redirect
from weather_api.key import api_key
# from .forms import UserSignupForm
import requests
import math

# Create your views here.

def index(request):
    return render(request, 'home.html')

def signup(request):
    return render(request, 'signup.html')


def result(request):
    if request.method == "POST":
        city_name = request.POST["city"].lower()
        url = f"http://api.openweathermap.org/data/2.5/forecast?q={city_name}&units=metric&appid={api_key}"
        w_dataset = requests.get(url).json()
        try:
            context = {
            
                "city_name":w_dataset["city"]["name"],
                "city_country":w_dataset["city"]["country"],
                "wind":w_dataset['list'][0]['wind']['speed'],
                "wind1":w_dataset['list'][1]['wind']['speed'],
                "wind2":w_dataset['list'][2]['wind']['speed'],
                "wind3":w_dataset['list'][3]['wind']['speed'],
                "wind4":w_dataset['list'][4]['wind']['speed'],
                "wind5":w_dataset['list'][5]['wind']['speed'],
                "wind6":w_dataset['list'][6]['wind']['speed'],
                "wind7":w_dataset['list'][7]['wind']['speed'],
                "wind8":w_dataset['list'][8]['wind']['speed'],
                "wind9":w_dataset['list'][9]['wind']['speed'],
                "wind10":w_dataset['list'][10]['wind']['speed'],
                "wind11":w_dataset['list'][11]['wind']['speed'],
                "wind12":w_dataset['list'][12]['wind']['speed'],


                "degree":w_dataset['list'][0]['wind']['deg'],
                "degree1":w_dataset['list'][1]['wind']['deg'],
                "degree2":w_dataset['list'][2]['wind']['deg'],
                "degree3":w_dataset['list'][3]['wind']['deg'],
                "degree4":w_dataset['list'][4]['wind']['deg'],
                "degree5":w_dataset['list'][5]['wind']['deg'],
                "degree6":w_dataset['list'][6]['wind']['deg'],
                "degree7":w_dataset['list'][7]['wind']['deg'],
                "degree8":w_dataset['list'][8]['wind']['deg'],
                "degree9":w_dataset['list'][9]['wind']['deg'],
                "degree10":w_dataset['list'][10]['wind']['deg'],
                "degree11":w_dataset['list'][11]['wind']['deg'],
                "degree12":w_dataset['list'][12]['wind']['deg'],
                "degree13":w_dataset['list'][13]['wind']['deg'],
                "degree14":w_dataset['list'][14]['wind']['deg'],


                
                "status":w_dataset['list'][0]['weather'][0]['description'],
                "status1":w_dataset['list'][1]['weather'][0]['description'],
                "status2":w_dataset['list'][2]['weather'][0]['description'],
                "status3":w_dataset['list'][3]['weather'][0]['description'],
                "status4":w_dataset['list'][4]['weather'][0]['description'],
                "status5":w_dataset['list'][5]['weather'][0]['description'],
                "status6":w_dataset['list'][6]['weather'][0]['description'],
                "status7":w_dataset['list'][7]['weather'][0]['description'],
                "status8":w_dataset['list'][8]['weather'][0]['description'],
                "status9":w_dataset['list'][9]['weather'][0]['description'],
                "status10":w_dataset['list'][10]['weather'][0]['description'],
                "status11":w_dataset['list'][11]['weather'][0]['description'],
                "status12":w_dataset['list'][12]['weather'][0]['description'],
                "status13":w_dataset['list'][13]['weather'][0]['description'],
                "status14":w_dataset['list'][14]['weather'][0]['description'],


                "cloud":w_dataset['list'][0]['clouds']['all'],
                'date':w_dataset['list'][0]["dt_txt"],
                'date1':w_dataset['list'][1]["dt_txt"],
                'date2':w_dataset['list'][2]["dt_txt"],
                'date3':w_dataset['list'][3]["dt_txt"],
                'date4':w_dataset['list'][4]["dt_txt"],
                'date5':w_dataset['list'][5]["dt_txt"],
                'date6':w_dataset['list'][6]["dt_txt"],
                'date7':w_dataset['list'][7]["dt_txt"],
                'date8':w_dataset['list'][8]["dt_txt"],
                'date9':w_dataset['list'][9]["dt_txt"],
                'date10':w_dataset['list'][10]["dt_txt"],
                'date11':w_dataset['list'][11]["dt_txt"],
                'date12':w_dataset['list'][12]["dt_txt"],
                'date13':w_dataset['list'][13]["dt_txt"],
                'date14':w_dataset['list'][14]["dt_txt"],



                "temp":w_dataset["list"][0]["main"]["temp"],
                "temp1":math.floor(w_dataset["list"][1]["main"]["temp"]),
                "temp2":math.floor(w_dataset["list"][2]["main"]["temp"]),
                "temp3":math.floor(w_dataset["list"][3]["main"]["temp"]),
                "temp4":math.floor(w_dataset["list"][4]["main"]["temp"]),
                "temp5":math.floor(w_dataset["list"][5]["main"]["temp"]),
                "temp6":math.floor(w_dataset["list"][6]["main"]["temp"]),
                "temp7":math.floor(w_dataset["list"][7]["main"]["temp"]),
                "temp8":math.floor(w_dataset["list"][8]["main"]["temp"]),
                "temp9":math.floor(w_dataset["list"][9]["main"]["temp"]),
                "temp10":math.floor(w_dataset["list"][10]["main"]["temp"]),
                "temp11":math.floor(w_dataset["list"][11]["main"]["temp"]),
                "temp12":math.floor(w_dataset["list"][12]["main"]["temp"]),
                "temp13":math.floor(w_dataset["list"][13]["main"]["temp"]),
                "temp14":math.floor(w_dataset["list"][14]["main"]["temp"]),

               

                "pressure":w_dataset["list"][0]["main"]["pressure"],
                "humidity":w_dataset["list"][0]["main"]["humidity"],
                "humidity1":w_dataset["list"][1]["main"]["humidity"],
                "humidity2":w_dataset["list"][2]["main"]["humidity"],
                "humidity3":w_dataset["list"][3]["main"]["humidity"],
                "humidity4":w_dataset["list"][4]["main"]["humidity"],
                "humidity5":w_dataset["list"][5]["main"]["humidity"],
                "humidity6":w_dataset["list"][6]["main"]["humidity"],
                "humidity7":w_dataset["list"][7]["main"]["humidity"],
                "humidity8":w_dataset["list"][8]["main"]["humidity"],
                "humidity9":w_dataset["list"][9]["main"]["humidity"],
                "humidity10":w_dataset["list"][10]["main"]["humidity"],
                "humidity11":w_dataset["list"][11]["main"]["humidity"],
                "humidity12":w_dataset["list"][12]["main"]["humidity"],
                "humidity13":w_dataset["list"][13]["main"]["humidity"],
                "humidity14":w_dataset["list"][14]["main"]["humidity"],

                


                "sea_level":w_dataset["list"][0]["main"]["sea_level"],


                "weather":w_dataset["list"][1]["weather"][0]["main"],
                "description":w_dataset["list"][1]["weather"][0]["description"],
                "icon":w_dataset["list"][0]["weather"][0]["icon"],
                "icon1":w_dataset["list"][1]["weather"][0]["icon"],
                "icon2":w_dataset["list"][2]["weather"][0]["icon"],
                "icon3":w_dataset["list"][3]["weather"][0]["icon"],
                "icon4":w_dataset["list"][4]["weather"][0]["icon"],
                "icon5":w_dataset["list"][5]["weather"][0]["icon"],
                "icon6":w_dataset["list"][6]["weather"][0]["icon"],
                "icon7":w_dataset["list"][7]["weather"][0]["icon"],
                "icon8":w_dataset["list"][8]["weather"][0]["icon"],
                "icon9":w_dataset["list"][9]["weather"][0]["icon"],
                "icon10":w_dataset["list"][10]["weather"][0]["icon"],
                "icon11":w_dataset["list"][11]["weather"][0]["icon"],
                "icon12":w_dataset["list"][12]["weather"][0]["icon"],
                "icon13":w_dataset["list"][13]["weather"][0]["icon"],
                "icon14":w_dataset["list"][14]["weather"][0]["icon"],
                # "icon15":w_dataset["list"][15]["weather"][0]["icon"],
                # "icon16":w_dataset["list"][16]["weather"][0]["icon"],
                # "icon17":w_dataset["list"][17]["weather"][0]["icon"],
                # "icon18":w_dataset["list"][18]["weather"][0]["icon"],
                # "icon19":w_dataset["list"][19]["weather"][0]["icon"],
                # "icon20":w_dataset["list"][20]["weather"][0]["icon"],
                # "icon21":w_dataset["list"][21]["weather"][0]["icon"],
                # "icon22":w_dataset["list"][22]["weather"][0]["icon"],
                # "icon23":w_dataset["list"][23]["weather"][0]["icon"],
                # "icon24":w_dataset["list"][24]["weather"][0]["icon"],
                # "icon25":w_dataset["list"][25]["weather"][0]["icon"],
                # "icon26":w_dataset["list"][26]["weather"][0]["icon"],
                # "icon27":w_dataset["list"][27]["weather"][0]["icon"],
                # "icon28":w_dataset["list"][28]["weather"][0]["icon"],
                # "icon29":w_dataset["list"][29]["weather"][0]["icon"],



            }
        except:
            context = {

            "city_name":"Not Found, Check your spelling..."
        }

        return render(request, 'results.html', context)
    else:
    	return redirect('home')


# def social_links(request):
#     sl = Social.objects.all()
#     context = {
#         'sl': sl
#     }
#     return render(request, 'weather_api/base.html', context)
