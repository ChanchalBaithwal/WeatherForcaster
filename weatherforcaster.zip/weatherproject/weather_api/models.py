from django.db import models

# Create your models here.
class whole_city(models.Model):
    city_Names = models.TextField(max_length=100)

    def _str_(self):
        return self.city_Names